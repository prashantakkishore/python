from distutils.core import setup

setup(

    name='printer',
    version='1.0',
    py_modules=['printing'],

    # metadata
    author='prashantak'

)